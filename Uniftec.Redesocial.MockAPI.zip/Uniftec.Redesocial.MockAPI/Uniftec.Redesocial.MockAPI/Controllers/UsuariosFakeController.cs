using Microsoft.AspNetCore.Mvc;
using Uniftec.Redesocial.MockAPI.Models;


namespace MockAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuariosFakeController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var lista = new List<UsuarioModel>
            {
                new UsuarioModel
                {
                    ID = Guid.NewGuid(),
                    Nome = "Jo�o API",
                    Username = "joao.api",
                    Senha = "123456",
                    DataNascimento = new DateTime(1995, 5, 1),
                    Genero = "Masculino",
                    Descricao = "Usu�rio simulado",
                    Publicacoes = 3,
                    Seguidores = 15,
                    Seguindo = 20,
                    FotoPerfil = "~/Imagens/avatar-default.png"
                }
            };

            return Ok(lista);
        }
    }
}
