var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();

// ? Habilita endpoints e Swagger UI
builder.Services.AddEndpointsApiExplorer();
object value = builder.Services.AddSwaggerGen(); // ? habilita gera��o do Swagger

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();        // ? habilita arquivo swagger.json
    app.UseSwaggerUI();      // ? habilita interface do Swagger
}

app.UseAuthorization();

app.MapControllers();

app.Run();
