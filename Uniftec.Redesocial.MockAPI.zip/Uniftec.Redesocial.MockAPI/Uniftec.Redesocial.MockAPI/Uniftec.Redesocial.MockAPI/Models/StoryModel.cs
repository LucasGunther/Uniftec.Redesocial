﻿namespace Uniftec.Redesocial.MockAPI.Models
{
    public class StoryModel
    {
        public Guid Id { get; set; }
        public Guid IdUsuario { get; set; }
        public string ImagemUrl { get; set; }
        public DateTime DataExpiracao { get; set; }
    }
}
