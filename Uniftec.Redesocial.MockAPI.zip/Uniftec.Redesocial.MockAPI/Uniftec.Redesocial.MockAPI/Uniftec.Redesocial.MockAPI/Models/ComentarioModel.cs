﻿namespace Uniftec.Redesocial.MockAPI.Models
{
    public class ComentarioModel
    {
        public Guid Id { get; set; }
        public Guid IdPost { get; set; }
        public Guid IdUsuario { get; set; }
        public string NomeAutor { get; set; } // ✅ novo campo
        public string Texto { get; set; }
        public DateTime DataComentario { get; set; }
    }
}
