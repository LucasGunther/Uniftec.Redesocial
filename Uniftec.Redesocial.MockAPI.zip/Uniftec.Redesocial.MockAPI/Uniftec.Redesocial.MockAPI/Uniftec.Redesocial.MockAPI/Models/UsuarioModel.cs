﻿using System;

namespace Uniftec.Redesocial.MockAPI.Models

{
    public class UsuarioModel
    {
        public Guid ID { get; set; }
        public string Nome { get; set; }
        public string Username { get; set; }
        public string Senha { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Genero { get; set; }
        public string Descricao { get; set; }
        public int Publicacoes { get; set; }
        public int Seguidores { get; set; }
        public int Seguindo { get; set; }
        public string FotoPerfil { get; set; }
    }
}
