﻿using Microsoft.AspNetCore.Mvc;
using Uniftec.Redesocial.MockAPI.Models;

namespace Uniftec.Redesocial.MockAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StoriesFakeController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var lista = new List<StoryModel>
            {
                new StoryModel
                {
                    Id = Guid.NewGuid(),
                    IdUsuario = Guid.NewGuid(),
                    ImagemUrl = "~/Imagens/story1.jpg",
                    DataExpiracao = DateTime.Now.AddHours(24)
                }
            };

            return Ok(lista);
        }
    }
}
