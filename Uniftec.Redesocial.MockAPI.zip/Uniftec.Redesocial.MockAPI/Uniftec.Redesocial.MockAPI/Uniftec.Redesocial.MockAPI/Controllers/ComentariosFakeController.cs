﻿using Microsoft.AspNetCore.Mvc;
using Uniftec.Redesocial.MockAPI.Models;

namespace Uniftec.Redesocial.MockAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ComentariosFakeController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var lista = new List<ComentarioModel>
            {
                new ComentarioModel
                {
                    Id = Guid.NewGuid(),
                    IdPost = Guid.NewGuid(),
                    IdUsuario = Guid.NewGuid(),
                    NomeAutor = "Lucas Gunther",
                    Texto = "Esse post está ótimo!",
                    DataComentario = DateTime.Now.AddMinutes(-10)
                }
            };

            return Ok(lista);
        }
    }
}
